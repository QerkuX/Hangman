//Wszystkie poziomy narysowania wisielca
const hangman_stages = [
    "  +---+<br>  |   |<br>      |<br>      |<br>      |<br>      |<br>=========<br>",
    "  +---+<br>  |   |<br>  O   |<br>      |<br>      |<br>      |<br>=========<br>",
    "  +---+<br>  |   |<br>  O   |<br>  |   |<br>      |<br>      |<br>=========<br>",
    "  +---+<br>  |   |<br>  O   |<br> /|   |<br>      |<br>      |<br>=========<br>",
    "  +---+<br>  |   |<br>  O   |<br> /|\\  |<br>      |<br>      |<br>=========<br>",
    "  +---+<br>  |   |<br>  O   |<br> /|\\  |<br> /    |<br>      |<br>=========<br>",
    "  +---+<br>  |   |<br>  O   |<br> /|\\  |<br> / \\  |<br>      |<br>=========<br>"
];
const passwords = ["apetyt rośnie w miarę jedzenia", "baba z wozu, koniom lżej", "biednemu zawsze wiatr w oczy", "broda mędrcem nie czyni", "cel uświęca środki", "ciekawość to pierwszy stopień do piekła", "co dwie głowy, to nie jedna", "co kraj, to obyczaj", "czas to pieniądz", "człowiek strzela, pan bóg kule nosi", "darowanemu koniowi w zęby się nie zagląda", "dla chcącego nic trudnego", "dobrymi chęciami jest piekło wybrukowane", "hulaj dusza piekła nie ma", "indyk myślał o niedzieli, a w sobotę łeb mu ścięli", "jak cię widzą, tak cię piszą", "kłamstwo ma krótkie nogi", "kuć żelazo, póki gorące", "łaska pańska na pstrym koniu jeździ", "mądry polak po szkodzie", "na złodzieju czapka gore", "nie taki diabeł straszny, jak go malują", "od piwa głowa się kiwa", "robota nie zając, nie ucieknie", "skleroza nie boli, ale nachodzić się trzeba", "stara miłość nie rdzewieje", "ten się śmieje, kto się śmieje ostatni", "uderz w stół, a nożyce się odezwą", "wilk syty i owca cała", "wysoki jak brzoza, a głupi jak koza", "zapomniał wół, jak cielęciem był"];

const letters = document.getElementsByClassName("letter");
const hangman = document.getElementById("hangman");
const password_container = document.getElementById("password");
const quess = document.getElementById("quess");
const title = document.getElementById("title");

var selected_letters = [];
var stage = 0;
var password = "";
var known_letters = [];
var unknown_letters = 0;
var end = false;

function show_info(){
    alert("1. Strona autorstwa Marka Miedzianowskiego.\n2. Hasła to polskie przysłowa (małe litery, polskie znaki).\n3. Wygrać można wybierając wszystkie poprawne litery lub wpisując całe hasło.\n4. Pokazanie hasła automatycznie kończy się przegraną.\n5. W konsoli znajduje się poprawne hasło.");
}

function game_over(){
    title.style.color = "#cf848f";
    title.textContent = "Przegrałeś!";
    end = true;
    password_container.textContent = password;
}


//Resetuje hasło, generuje '_' i ',' oraz liczy litery do zgadnięcia
function reset_password(){
    password = passwords[Math.floor(Math.random() * passwords.length)];
    for (var i = 0; i < password.length; i++){
        if (password[i] == " "){
            known_letters.push(" ");
            continue;
        }

        if (password[i] == ","){
            known_letters.push(",");
            continue;
        }

        known_letters.push("_");
        unknown_letters += 1;
    };

    password_container.textContent = known_letters.join("");
}

//Sprawdza czy podane hasło jest poprawne
function win_condition(won = false){
    if (quess.value == password || won){
        title.style.color = "#89b38b";
        title.textContent = "Wygrałeś!";
        end = true;
        password_container.textContent = password;
        return;
    }
    change_stage();
}

//Rysuje wisielca
function change_stage(){
    if (stage == 6){
        return;
    }

    stage += 1;
    hangman.innerHTML = hangman_stages[stage];

    if (stage == 6){
        game_over();
    }
}

//Sprawdza czy podana liczba znajduje się w haśle 
function check_letter(letter_index){
    if (end || selected_letters.includes(letter_index)){return;}

    const letter = letters[letter_index].textContent.toLowerCase();
    var correct = false;

    for (var i = 0; i < password.length; i++){
        if (password[i] == letter){
            correct = true;
            known_letters[i] = letter;
            unknown_letters -= 1;
            continue;
        }
    }

    //Odpowiednio koloruje litere
    selected_letters.push(letter_index)
    letters[letter_index].style.color = "#e4e2de";

    if (!correct){
        letters[letter_index].style.background = "#cf848f";
        change_stage();
        return;
    }

    letters[letter_index].style.background = "#89b38b";
    password_container.textContent = known_letters.join("");

    //Jezeli nie ma juz nieznanych liter, wygrano gre
    if (unknown_letters == 0){
        win_condition(true);
    }
}

// Dodaje event listener do każdej litery
for (var i = 0; i < letters.length; i++){
    letters[i].addEventListener("click", check_letter.bind(this, i));
}

reset_password();
console.log("Super tajne dane nie czytac: ", password);